//Ejercicio 1: Construya una clase llamada Rectangulo que tenga los siguientes atributos: largo y ancho, y los siguientes metodos: perimetro() y area().
/*void Usage(int argc, char *argv[]);
void Usage(int argc, char *argv[]){
    /*Muestra el modo de uso
    if(argc != 3) {
        cout <<argv[0] <<": Falta el nombre del fichero" <<endl;
        cout <<"Pruebe" << argv[0] <<": --help para mas informacion" <<endl;
        exit(EXIT_SUCCESS);
    }
    string parameter{argv[1]};
    if(parameter == "--help"){
        const string kHelperText = "Este programa averigua la palabra mas larga con vocales y otra con consonantes";
    cout << kHelperText << endl;
    exit(EXIT_SUCCESS);
    }
}*/
#include<iostream>

using namespace std;

class Rectangulo{
    private:
        float largo,ancho;
    public: //metodos
        Rectangulo(float,float); //constructor
        void perimetro();
        void area();
};
Rectangulo::Rectangulo(float _largo, float _ancho){
    largo = _largo;
    ancho = _ancho;
}

void Rectangulo::perimetro(){
    float perimetro;
    perimetro= (2*largo) + (2*ancho);
    cout<<"El perimetro es: "<<perimetro<<endl;
}

void Rectangulo::area(){
    float area;
    area = largo * ancho;
    cout<<"El perimetro es: "<<area<<endl;
}




int main(){
    //Usage(argc,argv);
    float ancho,largo;
    cin>>ancho;
    cin>>largo;
    Rectangulo r1(largo,ancho);
    r1.perimetro();
    r1.area();

    return 0;
}