//estructura de POO
#include<iostream>
#include<stdlib.h>
#include<string>

using namespace std;

class Persona{
//atributos casi siempre privados.
    private: //atributos
        int edad;
        string nombre;
//Metodos casi siemrpre públicos
    public: //metodos.
        Persona(int, string); //Constructor de la clase.
        void leer();
        void correr();


};
//Constructor, nos sirve para inicializar los atributos
Persona::Persona(int _edad,string _nombre){
    edad = _edad;
    nombre =_nombre;
}
void Persona::leer(){
    cout<<"Soy "<<nombre<<" y estoy leyendo un libro"<<endl;
}
void Persona::correr(){ 
    cout<<"Soy "<<nombre<<" y estoy corriendo rapido con "<<edad<<" años"<<endl;
}


int main(){
    //crear objeto
    Persona p1 = Persona(18,"Samuel"); //dar los atributos al objeto
    Persona p2(19,"Maria");
    Persona p3(21,"Juan");
    p1.leer(); //llamamos al metodo leer con el objeto p1
    p2.correr();
    p3.correr();
    p3.leer();
    system("pause");
    return 0;
}