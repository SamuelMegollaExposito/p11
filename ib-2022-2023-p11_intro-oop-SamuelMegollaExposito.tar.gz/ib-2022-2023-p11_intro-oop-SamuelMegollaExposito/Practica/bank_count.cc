#include <iostream>
#include <string>
#include <vector>
using namespace std;
class Cuenta {
  
  private: //atributos (privado)
    string titular;
    int cuenta;
    int edad;
    string tipoCuenta;
    float saldo;

  public: //metodos (publicos)
    Cuenta(string titular_, int cuenta_, int edad_, float saldo_) { //constructor
      titular = titular_;
      cuenta = cuenta_;
      edad = edad_;
      saldo = saldo_;

      if (esJoven()) { //comprobar el tipo de cuenta
        tipoCuenta = "Jover";
      } else {
        tipoCuenta = "Normal";
      }
    }
    bool esJoven() { //Comprobacion de joven
      return edad < 26;
    }
    //getters
    string getTitular() {  //recoge Titular
      return titular;
    }
    int getcuenta() { //recoge el numero de la cuenta
      return cuenta;
    }
    int getEdad() { //recoge la edad 
      return edad;
    }
    string getTipoCuenta() {  //recoge le tipo de cuenta
      return tipoCuenta;
    }
    float getSaldo() { //recoge el saldo
      return saldo;
    }
    
};
//Creacion de una cuenta nueva (opcion 1)
const int max_cuentas = 10;
vector<Cuenta> cuentas;
void CrearCuenta() {
  if(cuentas.size() > max_cuentas){
    cout << "Ha alcanzado el límite de cuentas permitidas." << endl;
  }
  string titular;
  cout << "Ingrese el nombre del titular: ";
  cin >> titular;
  int cuenta;
  cout << "Ingrese el número de cuenta: ";
  cin >> cuenta;
  int edad;
  cout << "Ingrese la edad del titular: ";
  cin >> edad;
  float saldo;
  cout << "Ingrese el saldo  actual: ";
  cin >> saldo;
  cuentas.push_back(Cuenta(titular, cuenta, edad, saldo));

}
//retirada de saldo (opcion 2)
    void Retirar(string titular, float cantidad) {
  for (int i = 0; i < cuentas.size(); i++) {
    if (cuentas[i].getTitular() == titular) {
      float saldo = cuentas[i].getSaldo();
      if (saldo - cantidad < 0) {
        cout << "Saldo insuficiente." << endl;
      }
    cuentas[i].setSaldo(saldo - cantidad);
    cout << "Retiro realizado completado" << endl;
    }
}
  cout << "No se encontró la cuenta con el titular " << titular << endl;
}

// Hacer un ingreso (opcion 3)
void Ingresar(string titular, float cantidad){
  for(int i = 0; i < cuentas.size(); i++){
    if(cuentas[i].getTitular() == titular){
      cuentas[i].setSaldo(cuentas[i].getSaldo() + cantidad);
      cout << "Ingreso completado" << endl;      
    }
  }
  cout << "No se encontró la cuenta con el titular " << titular << endl;
}
//Mostrar informacion de la cuenta (opcion 4)
void Informacion(){

}

//Mostrar informacion de todas las cuentas (opcion 5)
void MostrarCuentas() {
  for (int i = 0; i < cuentas.size(); i++) {
    cout << "Titular: " << cuentas[i].getTitular() << endl;
    cout << "Numero de cuenta: " << cuentas[i].getcuenta() << endl;
    cout << "Edad: " << cuentas[i].getEdad() << endl;
    cout << "Tipo de cuenta: " << cuentas[i].getTipoCuenta() << endl;
    cout << "Saldo: " << cuentas[i].getSaldo() << endl;
    cout << std::endl;
  }
}
//Obtener el saldo minimo entre todas las cuentas (opcion 6)


//funcion principal
int main(){
  int opcion;
  while(opcion != 0){
    cout << "1. Crear una cuenta nueva." << endl;
    cout << "2. Retirar saldo." << endl;
    cout << "3. Hacer un ingreso." << endl;
    cout << "4. Mostrar información de la cuenta" << endl;
    cout << "5. Mostrar información de todas las cuentas." << endl;
    cout << "6. Mostrar el menor saldo entre todas las cuentas."<<endl;
    cout << "0. Salir" << endl; 
    cout << "Seleccione una opción: "<<endl;
    cin >> opcion;
    switch (opcion)
    {
    case 1:
        CrearCuenta();
        break;
    case 2:
        Retirar();
        break;
    case 3:
        Ingresar();
        break;
    case 4:
        Informacion();
        break;

    case 5:
        MostrarCuentas();
        break;
    default:
        cout<<""
        break;
    }
  }
  return 0;
}