//sobre carga de Constructores.
#include<iostream>
#include<stdlib.h>
using namespace std;

class Fecha{
    private:
        int dia,mes,anio;
    public:
        Fecha(int,int,int); //constructor 1
        Fecha(long); //constructor 2
        void mostrarFecha();

};

//dia/mes/año ---- año/mes/dia
//constructor 1
Fecha::Fecha(int dia_,int mes_,int anio_){
    dia=dia_;
    mes=mes_;
    anio=anio_;
}
//Constructor 2
Fecha::Fecha(long fecha){
    anio = int(fecha/10000); //Extraer el año
    mes = int(fecha-anio*10000/100); //Extraer el mes
    dia = int(fecha-anio*10000-mes*100); //Extraer el dia
}
void Fecha::mostrarFecha(){
    cout<<"La fecha es: "<<dia<<"/"<<mes<<"/"<<anio<<endl;
}

int main(){
    Fecha hoy(22,12,2022); //actua con el constructor 1 
    Fecha ayer(20221221); //actua con el constructor 2
    hoy.mostrarFecha();
    ayer.mostrarFecha();


    return 0;
}